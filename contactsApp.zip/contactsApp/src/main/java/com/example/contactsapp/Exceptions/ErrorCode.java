package com.example.contactsapp.Exceptions;

public enum ErrorCode {
    INFO_REMAINING, DIALOG_ERROR, CONTACT_LOAD_ERROR, CONTACT_SAVE_ERROR
}
